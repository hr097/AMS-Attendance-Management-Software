#pragma once
#include<iostream>
#include<windows.h>
#include<strsafe.h>
#include<cctype>
#include<thread>
#include<ctype.h>
#include<regex>
namespace AMS1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Diagnostics;
	using namespace System::IO;
	using namespace System::Text::RegularExpressions;
	using namespace System::Net::Mail;
	using namespace System::Globalization;

	/// <summary>
	/// Summary for MyForm1
	/// </summary>
	public ref class MyForm1 : public System::Windows::Forms::Form
	{
	public:
		MyForm1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm1()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:



	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label11;
	private: System::Windows::Forms::TextBox^ textBox6;

	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker1;
	private: System::Windows::Forms::Label^ label12;
	private: System::Windows::Forms::TextBox^ textBox7;
	private: System::Windows::Forms::TextBox^ textBox3;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::TextBox^ textBox4;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::Label^ label13;
	private: System::Windows::Forms::TextBox^ textBox5;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm1::typeid));
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->dateTimePicker1 = (gcnew System::Windows::Forms::DateTimePicker());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->panel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label4->Location = System::Drawing::Point(633, 23);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(191, 53);
			this->label4->TabIndex = 5;
			this->label4->Text = L"Sign Up";
			// 
			// textBox1
			// 
			this->textBox1->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Append;
			this->textBox1->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox1->Location = System::Drawing::Point(427, 134);
			this->textBox1->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(591, 30);
			this->textBox1->TabIndex = 6;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label5->Location = System::Drawing::Point(448, 118);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(101, 22);
			this->label5->TabIndex = 7;
			this->label5->Text = L"Full Name";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label11->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label11->Location = System::Drawing::Point(448, 190);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(175, 22);
			this->label11->TabIndex = 23;
			this->label11->Text = L"Department Name";
			// 
			// textBox6
			// 
			this->textBox6->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Append;
			this->textBox6->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox6->Location = System::Drawing::Point(432, 206);
			this->textBox6->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(591, 30);
			this->textBox6->TabIndex = 24;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label6->Location = System::Drawing::Point(448, 255);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(126, 22);
			this->label6->TabIndex = 27;
			this->label6->Text = L"Joining Year";
			// 
			// dateTimePicker1
			// 
			this->dateTimePicker1->CustomFormat = L"yyyy";
			this->dateTimePicker1->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->dateTimePicker1->Format = System::Windows::Forms::DateTimePickerFormat::Custom;
			this->dateTimePicker1->Location = System::Drawing::Point(432, 272);
			this->dateTimePicker1->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->dateTimePicker1->MaxDate = System::DateTime(2021, 11, 11, 0, 0, 0, 0);
			this->dateTimePicker1->MinDate = System::DateTime(1900, 1, 1, 0, 0, 0, 0);
			this->dateTimePicker1->Name = L"dateTimePicker1";
			this->dateTimePicker1->ShowUpDown = true;
			this->dateTimePicker1->Size = System::Drawing::Size(591, 31);
			this->dateTimePicker1->TabIndex = 28;
			this->dateTimePicker1->Value = System::DateTime(2021, 11, 11, 0, 0, 0, 0);
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label12->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label12->Location = System::Drawing::Point(448, 321);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(148, 22);
			this->label12->TabIndex = 29;
			this->label12->Text = L"HOD\'s Email ID";
			// 
			// textBox7
			// 
			this->textBox7->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox7->Location = System::Drawing::Point(432, 338);
			this->textBox7->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox7->Name = L"textBox7";
			this->textBox7->Size = System::Drawing::Size(591, 30);
			this->textBox7->TabIndex = 30;
			// 
			// textBox3
			// 
			this->textBox3->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Suggest;
			this->textBox3->AutoCompleteSource = System::Windows::Forms::AutoCompleteSource::HistoryList;
			this->textBox3->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox3->Location = System::Drawing::Point(432, 404);
			this->textBox3->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(591, 30);
			this->textBox3->TabIndex = 31;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label7->Location = System::Drawing::Point(448, 386);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(134, 22);
			this->label7->TabIndex = 32;
			this->label7->Text = L"Your Email ID";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label9->Location = System::Drawing::Point(448, 454);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(104, 22);
			this->label9->TabIndex = 33;
			this->label9->Text = L"Username";
			// 
			// textBox2
			// 
			this->textBox2->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Suggest;
			this->textBox2->AutoCompleteSource = System::Windows::Forms::AutoCompleteSource::HistoryList;
			this->textBox2->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox2->Location = System::Drawing::Point(432, 473);
			this->textBox2->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox2->MaxLength = 8;
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(591, 30);
			this->textBox2->TabIndex = 34;
			// 
			// textBox4
			// 
			this->textBox4->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Suggest;
			this->textBox4->AutoCompleteSource = System::Windows::Forms::AutoCompleteSource::HistoryList;
			this->textBox4->Font = (gcnew System::Drawing::Font(L"Arial", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox4->Location = System::Drawing::Point(432, 538);
			this->textBox4->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox4->MaxLength = 20;
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(591, 27);
			this->textBox4->TabIndex = 35;
			this->textBox4->UseSystemPasswordChar = true;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label10->Location = System::Drawing::Point(448, 519);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(103, 22);
			this->label10->TabIndex = 36;
			this->label10->Text = L"Password";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->BackColor = System::Drawing::Color::Transparent;
			this->label13->Font = (gcnew System::Drawing::Font(L"Arial", 10.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label13->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(149)),
				static_cast<System::Int32>(static_cast<System::Byte>(211)));
			this->label13->Location = System::Drawing::Point(448, 582);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(186, 22);
			this->label13->TabIndex = 37;
			this->label13->Text = L"Re-enter Password";
			// 
			// textBox5
			// 
			this->textBox5->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Suggest;
			this->textBox5->AutoCompleteSource = System::Windows::Forms::AutoCompleteSource::HistoryList;
			this->textBox5->Font = (gcnew System::Drawing::Font(L"Arial", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox5->Location = System::Drawing::Point(432, 601);
			this->textBox5->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox5->MaxLength = 20;
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(591, 27);
			this->textBox5->TabIndex = 38;
			this->textBox5->UseSystemPasswordChar = true;
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::Black;
			this->button1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button1.BackgroundImage")));
			this->button1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button1->Cursor = System::Windows::Forms::Cursors::AppStarting;
			this->button1->FlatAppearance->BorderColor = System::Drawing::Color::CornflowerBlue;
			this->button1->FlatAppearance->BorderSize = 2;
			this->button1->FlatAppearance->MouseOverBackColor = System::Drawing::Color::Transparent;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::Color::White;
			this->button1->Location = System::Drawing::Point(507, 670);
			this->button1->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(191, 37);
			this->button1->TabIndex = 39;
			this->button1->Text = L"SIGN UP";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm1::button1_Click);
			// 
			// button2
			// 
			this->button2->Cursor = System::Windows::Forms::Cursors::AppStarting;
			this->button2->FlatAppearance->BorderColor = System::Drawing::Color::CornflowerBlue;
			this->button2->FlatAppearance->BorderSize = 2;
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button2->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 10.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(32)), static_cast<System::Int32>(static_cast<System::Byte>(148)),
				static_cast<System::Int32>(static_cast<System::Byte>(210)));
			this->button2->Location = System::Drawing::Point(756, 671);
			this->button2->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(191, 37);
			this->button2->TabIndex = 40;
			this->button2->Text = L"EXIT";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm1::button2_Click);
			// 
			// panel1
			// 
			this->panel1->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"panel1.BackgroundImage")));
			this->panel1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->label2);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Dock = System::Windows::Forms::DockStyle::Left;
			this->panel1->Location = System::Drawing::Point(0, 0);
			this->panel1->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(371, 750);
			this->panel1->TabIndex = 41;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"label3.Image")));
			this->label3->Location = System::Drawing::Point(63, 414);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(117, 19);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Presented by";
			this->label3->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Segoe Script", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"label2.Image")));
			this->label2->Location = System::Drawing::Point(168, 412);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(131, 23);
			this->label2->TabIndex = 6;
			this->label2->Text = L"  Secretself Info";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::White;
			this->label1->Font = (gcnew System::Drawing::Font(L"JetBrains Mono", 48, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"label1.Image")));
			this->label1->Location = System::Drawing::Point(43, 294);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(285, 106);
			this->label1->TabIndex = 1;
			this->label1->Text = L"A M S";
			// 
			// MyForm1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1095, 750);
			this->Controls->Add(this->label13);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textBox5);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->dateTimePicker1);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->textBox6);
			this->Controls->Add(this->textBox7);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->Name = L"MyForm1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"MyForm1";
			this->Load += gcnew System::EventHandler(this, &MyForm1::MyForm1_Load);
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	
private: System::Void MyForm1_Load(System::Object^ sender, System::EventArgs^ e) {

}
	   bool ISNumeric(String^ str)
	   {
		   bool hasNumber = false;
		   for (int i = 0; i < str->Length; i++)
		   {
			   if (Char::IsNumber(str[i]))
			   {
				   hasNumber = true;
				   break;
			   }
		   }
		   return hasNumber;
	   }
	   bool SpecialEmailValidation(String^ str)
	   {
		   Char special[] = { '_', ')', '(', '*', '%', '^', '&', '+', '=', '!' ,'-','\\','/','\,','\"','\'','?','#','$','[',']','\;',':','{','}','<','>','~','`', '|' };
		   bool hasSpecialChar = false;

		   for (int i = 0; i < str->Length; i++)
		   {
			   for (int j = 0; j < 30; j++)
			   {
				   if (str[i] == special[j])
				   {
					   hasSpecialChar = true;
					   break;
				   }
				   if (hasSpecialChar)
					   break;
			   }
		   }
		   return hasSpecialChar;
	   }
	   //has special symbols or not in string
	   bool ISSpecialSymbols(String^ str)
	   {
		   Char special[] = { '@', '#', '$', '%', '^', '&', '+', '=' };
		   bool hasSpecialChar = false;

		   for (int i = 0; i < str->Length; i++)
		   {
			   for (int j = 0; j < 8; j++)
			   {
				   if (str[i] == special[j])
				   {
					   hasSpecialChar = true;
					   break;
				   }
				   if (hasSpecialChar)
					   break;
			   }
		   }
		   return hasSpecialChar;
	   }
	   //Choice validation 
	   bool validateChoice(String^ input, int Bnd) //* string input validate as integer
	   {

		   bool flag = false;
		   for (int tem = 1; tem <= Bnd; tem++)
		   {

			   if (tem.ToString() == input) //convert tem int to string to check input valid condition
			   {
				   flag = true;
				   break;
			   }
		   }
		   return flag;
	   }
	   bool validateUsername(String^ username)
	   {
		   bool hasAlpha = false;
		   bool hasDigit = false;
		   int special = 0;
		   //check length is 0 or more than 30

		   for (int i = 0; i < username->Length; i++)
		   {

			   //characters other than alphabets and numbers
			   if (isalpha(username[i]))
			   {
				   hasAlpha = true;
			   }
			   else if (isdigit(username[i]))
			   {
				   hasDigit = true;
			   }
			   else
			   {
				   //periods and underscore allowed but only one
				   if (username[i] == '_' || username[i] == '.')
				   {
					   special++;
					   if (special > 1)
						   return false;
				   }
				   else
					   return false;
			   }
		   }
		   bool isvalid = hasAlpha && hasDigit;
		   return isvalid;
	   }
	   bool VaidateEmail(String^ Email)
	   {
		   Regex^ regex = gcnew Regex("(\\w+)(\\.|_)?(\\w*)@(\\w+)(\\.(\\w+))+");
		   bool isValid = regex->IsMatch(Email);
		   return isValid;
		   /*String^ pattern = "(\\w + )(\\. | _) ? (\\w*)@(\\w + )(\\.(\\w + )) + ";
		   if (Regex::IsMatch(textBox1->Text, pattern))
		   {
			   return true;
		   }
		   else
		   {
			   return false;
		   }*/
	   }








private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	if (textBox1->Text->Length == 0)//Empty Name box
	{
		MessageBox::Show("Please Enter Your Name!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	if (textBox6->Text->Length == 0)//Empty Department Name box
	{
		MessageBox::Show("Please Enter Department Name!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	/*if (ISNumeric(textBox1->Text))//Numeric Error
	{
		MessageBox::Show("Name doesn't contain Digits!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox1->Text = "";
		return;
	}
	if (ISSpecialSymbols(textBox1->Text))//Special Symbols Error
	{
		MessageBox::Show("Name doesn't contain Special Symbols!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox1->Text = "";
		return;
	}*/

	if (textBox7->Text->Length == 0)//HOD email validation and empty checking
	{
		MessageBox::Show("Please Enter HOD's Email Address!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	/*if (!VaidateEmail(textBox7->Text))
	{

		MessageBox::Show("Please Enter HOD's Valid Email Address", "INVALID EMAIL ADDRESS", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox7->Text = "";
		return;
	}*/
	/*if (SpecialEmailValidation(textBox7->Text) || textBox7->Text->IndexOf(" ") != -1)
	{
		MessageBox::Show("Please Enter HOD's Valid Email Address 123", "INVALID EMAIL ADDRESS", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox7->Text = "";
		return;
	}*/
	

	String^ pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
	if (!Regex::IsMatch(textBox7->Text, pattern))
	{
		MessageBox::Show("Please Enter HOD's Valid Email Address!", "INVALID EMAIL ADDRESS", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox7->Text = "";
		return;
	}
	
	


	if (textBox3->Text->Length == 0)//Email box Empty
	{
		MessageBox::Show("Please Enter Your Email Address!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	
	if (!Regex::IsMatch(textBox3->Text, pattern))
	{
		MessageBox::Show("Please Enter Your Valid Email Address!", "INVALID EMAIL ADDRESS", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox3->Text = "";
		return;
	}
	/*if (!VaidateEmail(textBox3->Text))
	{
		MessageBox::Show("Please Enter Your Valid Email Address!", "INVALID EMAIL ADDRESS", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox3->Text = "";
		return;
	}
	if (SpecialEmailValidation(textBox3->Text) || textBox3->Text->IndexOf(" ") != -1)
	{
		MessageBox::Show("Please Enter Your Valid Email Address 123", "INVALID EMAIL ADDRESS", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox3->Text = "";
		return;
	}*/
	if (textBox2->Text->Length == 0)//username empty
	{
		MessageBox::Show("Please Enter a Username!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	if (textBox2->Text->Length < 4 || textBox2->Text->Length > 8)//Lenghth Error
	{
		MessageBox::Show("Username Length must be between 4 to 8", "INVALID USERNAME LENGTH", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox2->Text = "";
		return;
	}
	if (textBox2->Text->IndexOf(" ") != -1)
	{
		MessageBox::Show("Username doesn't contain Space!", "INVALID USERNAME", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox2->Text = "";
		return;
	}
	if (!validateUsername(textBox2->Text))
	{
		MessageBox::Show("Username must contain an alphabet, a digit, Meximum one Underscore or dot", "INVALID USERNAME", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox2->Text = "";
		return;
	}
	if (textBox4->Text->Length == 0)//Empty Password
	{
		MessageBox::Show("Please Enter a Password!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	if (textBox4->Text->Length < 8 || textBox4->Text->Length > 20)//Lenghth Error
	{
		MessageBox::Show("Password Length must be between 8 to 20", "INVALID PASSWORD LENGTH", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox4->Text = "";
		return;
	}
	if (!ValidatePassword(textBox4->Text))//validation of Password
	{
		MessageBox::Show("Password must contain a Lowercase letter, an Uppercase letter, a Special Symbole and a Digit", "INVALID PASSWORD", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox4->Text = "";
		return;
	}
	if (textBox5->Text->Length == 0)//empty Re entered password
	{
		MessageBox::Show("Please Enter Your Confirmation Password!", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}
	if (textBox4->Text != textBox5->Text)//comparision between Password and reentered password
	{
		MessageBox::Show("Please Check Your Password", "INVALID RE-ENTERED PASSWORD", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox5->Text = "";
		return;
	}
	String^ License = "SS09";
	//welcome email sending
	try {
		MailMessage^ message = gcnew MailMessage();
		SmtpClient^ smtp = gcnew SmtpClient();
		message->From = gcnew MailAddress("pshlok4105@gmail.com");
		message->To->Add(gcnew MailAddress(textBox3->Text));
		message->Subject = "Welcome To AMS";
		message->IsBodyHtml = true; //to make message body as html  
		message->Body = "<p style=\"font-size:20px;\">Hi " + textBox1->Text + ",</p><br><h2>Welcome to Attendance Managment System.<br>" + "<mark>License key  : " + License + "</mark><br></h2><br><p style=\"font-size:20px;\">We at AMS are excited to have you onboard and we�d love to say thank you on behalf of our whole company for choosing us. We believe <b>AMS(Attendance Managment System)</b> will help you to manage daily attendace reports without any inconvenience.</p><br/><p style=\"font-size:20px;\">With increasing working hours and less classroom time, teachers need edTech tools that help them to manage precious class time efficiently. Instead of focusing on teaching, faculty members are often stuck with completing formal duties, for e.g. taking daily student attendance.</p><br/><p style=\"font-size:20px;\">Traditionally, the process of taking and managing attendance is very Unreliable for getting precious records all the students. But AMS provides you best and quick way of taking the attendance where you can customize attendance reports. </p><br/><p style=\"font-size:20px;\">An attendance management system's features play a key role in making time and attendance tracking easier which saves your time and effort.</p><br><br><p style=\"font-size:20px;\"> Have any questions for us or need more information ? Just shoot us an email!We�re always here to help.<br></p><p style=\"font-size:20px;\"><b><u>Team AMS</u><b/></p>";
		smtp->Port = 587;
		smtp->Host = "smtp.gmail.com"; //for gmail host  
		smtp->EnableSsl = true;
		smtp->UseDefaultCredentials = false;
		smtp->Credentials = gcnew System::Net::NetworkCredential("secretselfinfotech@gmail.com", "SS09@@##");
		smtp->DeliveryMethod = SmtpDeliveryMethod::Network;
		smtp->Send(message);
		MessageBox::Show("Email is sent to " + textBox3->Text, "WELCOME TO AMS", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	catch (Exception^ ex)
	{
		MessageBox::Show("Please Enter Your Valid Email Address!", "INVALID EMAIL ADDRESS", MessageBoxButtons::OK, MessageBoxIcon::Error);
		textBox3->Text = "";
		return;
	}
	//Ams Folder creating and data writing
	String^ APP_PATH = Environment::GetFolderPath(Environment::SpecialFolder::MyDocuments) + "\\AMS";
	Directory::CreateDirectory(APP_PATH);
	Directory::CreateDirectory(APP_PATH + "\\LOG-INFO\\APPLOG");
	//File::Create(APP_PATH + "\\LOG-INFO\\login-Credentials.txt");
	//File::Create(APP_PATH + "\\LOG-INFO\\APPLOG\\logs.txt");
	Directory::CreateDirectory(APP_PATH + "\\USER-INFO");
	//File::Create(APP_PATH + "\\USER-INFO\\user-Details.txt");
	Directory::CreateDirectory(APP_PATH + "\\OTHER");
	File::Create(APP_PATH + "\\OTHER\\semesterRecord.txt");

	StreamWriter^ sw = gcnew StreamWriter(APP_PATH + "\\USER-INFO\\userdetails.txt");
	sw->WriteLine(textBox1->Text);//name
	sw->WriteLine(textBox6->Text);//department name
	sw->WriteLine(dateTimePicker1->Text);//joining year
	sw->WriteLine(textBox7->Text->ToLower());//hadof department email
	sw->WriteLine(textBox3->Text->ToLower());//Email
	sw->Close();

	sw = gcnew StreamWriter(APP_PATH + "\\LOG-INFO\\logincredentials.txt");
	sw->WriteLine(textBox3->Text->ToLower());//Email
	sw->WriteLine(textBox2->Text);//username
	sw->WriteLine(textBox4->Text);//password
	sw->WriteLine(License);//License key
	sw->Close();

	DateTime^ now = DateTime::Now;
	sw = File::AppendText(APP_PATH + "\\LOG-INFO\\APPLOG\\logs.txt");
	sw->WriteLine(now);
	sw->Close();

	MessageBox::Show("Redirecting....", "Correct Password", MessageBoxButtons::OK, MessageBoxIcon::Information);
	Application::Exit();

}
	   //password checking function
	   bool ValidatePassword(String^ password) {
		   const int MIN_LENGTH = 8;
		   const int MAX_LENGTH = 20;
		   bool meetsLengthRequirements = password->Length >= MIN_LENGTH && password->Length <= MAX_LENGTH;
		   bool hasUpperCaseLetter = false;
		   bool hasLowerCaseLetter = false;
		   bool hasDecimalDigit = false;
		   bool hasSpecialChar = ISSpecialSymbols(password);
		   if (meetsLengthRequirements)
		   {
			   for (int i = 0; i < password->Length; i++)
			   {

				   if (Char::IsUpper(password[i])) hasUpperCaseLetter = true;
				   else if (Char::IsLower(password[i])) hasLowerCaseLetter = true;
				   else if (Char::IsDigit(password[i])) hasDecimalDigit = true;
			   }
		   }
		   bool isValid = meetsLengthRequirements && hasUpperCaseLetter && hasLowerCaseLetter && hasDecimalDigit && hasSpecialChar;
		   return isValid;
}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	Application::Exit();
}
};
}
